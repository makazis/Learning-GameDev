from random import *
from math import *

pos=0
#-2 is nearest train station
#-1 is None
#-3 is back 3 spaces
#-4 is nearest utility

chances=[11,39,-1,-1,-2,-3,-1,-2,-4,24,-1,10,-1,5,-1,0]
chance_spots=[7,22,36]
chests=[-1 for i in range(14)]+[10,0]
chest_spots=[2,17,23]
#Board has 40 spaces, and we need to find out how likely it is to land on one of these spaces every tick
#On top of that, you get insta released from prison, as well 
distrib={i:0 for i in range(40)}
for i in range(1_000_000):
    pos+=randint(1,6)+randint(1,6)
    if pos>39:
        pos-=40
    if pos==30:
        pos=10
    if pos in chance_spots:
        roll=choice(chances)
        if 39>=roll>=0: #Move to space
            pos=roll
        elif roll==-3: #Move Three spaces back
            pos-=3
            pos%=40
        elif roll==-2: #Move to the nearest railroad
            pos=pos//10*10+5
        elif roll==-4: #Move to the closest utility
            if pos<20:
                pos=12
            else:
                pos=28
    if pos in chest_spots:
        roll=choice(chests)
        if 39>=roll>=0: #Move to space
            pos=roll
    distrib[pos]+=1
distrib_flipped={distrib[i]:i for i in distrib}
d_values=[distrib[i] for i in distrib]
new_d_values=sorted(d_values)

for i in range(40):
    print(distrib_flipped[new_d_values[i]])
for i in range(40):
    print(str(new_d_values[i]/1_000_000).replace(".",","))
sum(new_d_values)