from card import *
from Piece import *

starting_shop_items=[
        {
                "Type":"Piece",
                "Layout":[
                    {
                        "Position":[0,0],
                        "Type":"Block"
                    }
                ],
                "Color":[23,205,23],
                "Cost":{
                    "Earth":randint(randint(1,2),2)
                }
            } for i in range(3)
]+[
    {
        "Type":"Upgrade",
        "ID":"More Crystals",
        "Cost":{
            "Earth":5,
            "Water":5,
            "Air":5,
            "Fire":5,
            
        }
        }
]

class Item:
    def __init__(self,data):
        self.data=data
        self.type=self.data["Type"]
        if self.data["Type"]=="Piece":
            new_card=Card()
            new_object_manager=Piece({"Layout":[]},self.data["Color"])
            for i in self.data["Layout"]:
                new_object_manager.squares[tuple(i["Position"])]=cube(i["Type"],self.data["Color"])
            new_object_manager.card=new_card
            new_object_manager.possible_moves=[None,None]
            new_object_manager.draw() #Draws the new card at the start, so it is visible at all
            new_card.parent=new_object_manager #Also attributes the parent to whatever is locked inside the card
            self.card=new_card
            new_object_manager.update()
        if self.data["Type"]=="Upgrade":
            self.card=Card()
            self.card.sides["Front"].fill((0,25,55))
        self.cost=[]
        #for i in range(4):
            #element=["Air","Water","Earth","Fire"][i]
            #if element in self.data["Cost"]:
        self.sprite=pygame.Surface((300,320))
        self.sprite.fill(card_transparency_color)
        self.sprite.set_colorkey(card_transparency_color)
    def draw(self): #Used so that you can flip cards in shop
        self.sprite.fill(card_transparency_color)
        self.card.draw()
        self.sprite.blit(self.card.sprite,(90,0))
        y_stack=0
        for i in range(4):
            element=["Air","Water","Earth","Fire"][i]
            if element in self.data["Cost"]:
                center(mini_crystal_sprite[i],self.sprite,60,64+y_stack*64)
                center(render_text(str(self.data["Cost"][element])),self.sprite,20,64+y_stack*64)
                y_stack+=1
starting_shop_items=[Item(i) for i in starting_shop_items]