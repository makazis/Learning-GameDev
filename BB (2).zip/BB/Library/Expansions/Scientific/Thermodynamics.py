from Library.Expansions.Main import *
from random import *
class Thermal_Expansion(Expansion):
    def __init__(self):
        super().__init__()
        self.display_name="Thermodynamics"
        self.display_description=["Pieces get colder over time.","Cold enough pieces aren't cleared,","they just become more warm.","Also adds hotter pieces, that","warm up the ones around them"]
        self.mutations=[
            {
                "ID":"Turn Cold",
                "Function":self.turn_cold,
                "Weight":3
            },{
                "ID":"Turn Hot",
                "Function":self.turn_hot,
                "Weight":3}
            ]
        self.flags=[
            "Cooling"
        ]
    def turn_cold(self,piece):
        options=set()
        for i in piece.squares:
            if piece.squares[i].type in ["Block","Cold"]:
                options.add(i)
        if len(options)>0:
            chosen_square=choice(list(options))
            if piece.squares[chosen_square].type=="Block":
                piece.squares[chosen_square]=cube("Cold",piece.color)
            elif piece.squares[chosen_square].type=="Cold":
                piece.squares[chosen_square].temperature-=50
    def turn_hot(self,piece):
        options=set()
        for i in piece.squares:
            if piece.squares[i].type in ["Block","Hot"]:
                options.add(i)
        if len(options)>0:
            chosen_square=choice(list(options))
            if piece.squares[chosen_square].type=="Block":
                piece.squares[chosen_square]=cube("Hot",piece.color)
            elif piece.squares[chosen_square].type=="Hot":
                piece.squares[chosen_square].temperature+=450

    