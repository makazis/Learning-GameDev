from Library.Expansions.Main import *

class Basic_Expansion(Expansion):
    def __init__(self):
        super().__init__()
        self.display_name="Strange Pieces"
        self.display_description=["Adds a mutation that removes blocks","And a mutation that adds them"]
        self.mutations=[
            {
                "ID":"Add Pieces",
                "Function":self.add_square_to_piece,
                "Weight":5
            },{
                "ID":"Remove Pieces",
                "Function":self.remove_square_from_a_piece,
                "Weight":5
            },

        ]
    def add_square_to_piece(self,piece):
        options=set()
        for ii in range(5): #X
            ii-=2
            for iii in range(5): #Y
                iii-=2
                if not (ii,iii) in piece.squares: #Found an empty square to place new sqaure into
                    for vector in [(0,1),(1,0),(-1,0),(0,-1)]:
                        if -2<=vector[0]+ii<=2 and -2<=vector[1]+iii<=2: #If destination fits inside the square
                            if (vector[0]+ii,vector[1]+iii) in piece.squares:
                                options.add((ii,iii))
        g=choice(tuple(options))
        piece.squares[g]=cube("Block",piece.color)
    def remove_square_from_a_piece(self,piece):
        if len(piece.squares)>1:
            del piece.squares[choice(tuple(piece.squares.keys()))]