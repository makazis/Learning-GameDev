from Library.Expansions.Main import *
from random import *
class Tough_Expansion(Expansion):
    def __init__(self):
        super().__init__()
        self.display_name="Tough Blocks"
        self.display_description=["Adds a mutation that turns blocks","harder"]
        self.mutations=[
            {
                "ID":"Become Tough",
                "Function":self.turn_negative,
                "Weight":6
            }
            ]
    def turn_negative(self,piece):
        options=set()
        for i in piece.squares:
            if piece.squares[i].type in ["Block","Tough"]:
                options.add(i)
        if len(options)>0:
            chosen_square=choice(list(options))
            if piece.squares[chosen_square].type=="Block":
                piece.squares[chosen_square]=cube("Tough",piece.color)
            elif piece.squares[chosen_square].type=="Tough":
                piece.squares[chosen_square].toughness+=1
            