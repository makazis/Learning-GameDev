from card import *
from Piece import *
class Card_Space:
    def __init__(self,tags={}):
        self.card=None
        self.tags=tags
        self.sprite=pygame.Surface((210,320))
        self.sprite.set_colorkey(card_transparency_color)
        self.almost_selected=False
    def draw(self):
        if self.card==None:
            self.sprite.fill(card_transparency_color)
            if self.almost_selected:
                pygame.draw.rect(self.sprite,(255,255,155),(0,0,210,320),10,15)
                self.almost_selected=False
            else:
                pygame.draw.rect(self.sprite,(155,255,255),(0,0,210,320),10,15)
        else:
            self.card.draw()
            center(self.card.sprite,self.sprite,105,160)
t_spar_space=pygame.Surface((100,100))
t_spar_space.set_colorkey((0,0,0))
t_spar_space.set_alpha(100)
pygame.draw.rect(t_spar_space,(105,0,0),(0,0,100,100),0,5)
class Board:
    def __init__(self,inherited_screen_size=(1920,1080)):
        self.locations={  #Contains all the data about where cards can exist
            "Board":[]
        }
        self.card_piles=[]
        self.surface=pygame.Surface((1920,1080))
        self.camera_x=-1920/2 
        self.camera_y=-1080/2 #Aligns the center to the center

        self.mouse_pos=[0,0] #Set to this for now, as it causes a crash if unset
        self.r_mouse_pos=[0,0]
        self.mouse_pos_multiplier=[[1920,1080][i]/inherited_screen_size[i] for i in range(2)] #Adjusts the mouse correctly
        self.drag_screen_allowed=True #Sets whether or not if you drag something, it will be dragged across the screen
        self.mouse_down=[False for i in range(3)]
        self.ctimer=[0,0,0]
        self.click=[False,False,False] #Can accurately detect the first frame when the mouse button is clicked
        self.game_over=False
        self.open_GUIs={}

        self.score=0
        self.combo_timer=0
        self.combo_score=0

        self.background_particles=[]
    def add_space_to_board(self,x_offset=0,y_offset=0,required_type=None,tags={}): #Adds a card spot to the board
        self.locations["Board"].append({
            "Space":Card_Space(tags),
            "X Offset":x_offset,
            "Y Offset":y_offset,
            "Type Needed":required_type,
            "Tags":tags
            })
    def setup_hand(self,max_cards=10):
        self.locations["Hand"]={
            "Position":[0,500], #Can be changed later if needed
            "Max Cards":max_cards,
            "Cards":[],
            "Curvature Settings":{ #Defines some stuff about how cards are held in hand, It's best not to think about this that much right now
                "Alpha":10, #How much the cards are bent
                "Beta":1.5, #Exponential of how far down the cards go, it's best to be kept small at larger number of cards
                "Gamma":10 #Card Descent Multiplier in pixels
            },
            "Card Rendered On Top":None,
            "Selected Card":None
        }
    def setup_card_pile(self,card_pile_name="Deck",pos=(900,0)):
        self.locations[card_pile_name]={
            "Position":pos,
            "Cards":[]
        }
        self.card_piles.append(card_pile_name)
    def draw(self):
        #self.camera_x*=1.01
        #self.camera_y*=1.01
        self.drag_screen_allowed=True
        self.surface.fill((25,5,5)) #Fills the board with a nice color to draw on
        #Draws the board at the very bottom
        #for i in range(5):
        #    i=4-i
        #    move_q=1-i/10
        #    for ii in range(i*5+5):
        #        if 255-50*i-ii*5>12:
        #            pygame.draw.rect(self.surface,(255-50*i-ii*5,0,0),(420-self.camera_x*move_q-500-100*i+ii*4,420-self.camera_y*move_q-500-i*100+ii*4,1000+200*i-ii*8,1000+i*200-ii*8),4)
        for i in range(12):
            if random()<0.8/12:
                theta=random()*tau
                pol=random()
                self.background_particles.append({
                    "position":(self.camera_x+960+cos(theta)*1200*pol,self.camera_y+960+sin(theta)*1200*pol),
                    "size":0,
                    "growth":random()*0.5+0.15,
                    "max size":randint(20,40)
                })
        for i in self.background_particles:
            i["size"]+=i["growth"]
            if i["size"]<=i["max size"]:
                s_q=i["size"]/i["max size"]
                pygame.draw.circle(self.surface,(255*s_q,0,0),(i["position"][0]-self.camera_x,i["position"][1]-self.camera_y),i["size"],7)
        for i in self.background_particles[::-1]:
            if i["size"]==i["max size"]:
                self.background_particles.remove(i)
        for I in self.locations["Board"]:
            #I=self.locations["Board"][i]
            I["Space"].draw()
            if I["Space"].card!=None:
                I["Space"].card.vector_space_element.x=I["X Offset"]
                I["Space"].card.vector_space_element.y=I["Y Offset"]
            center(I["Space"].sprite,self.surface,I["X Offset"]-self.camera_x,I["Y Offset"]-self.camera_y)
        for I,i in enumerate(self.locations["BBoard"]["Map"]):
            for II,ii in enumerate(i):
                iis=ii["Square"]
                is_being_destroyed=False
                animations_removed=[]
                for iii in ii["Animations"]: #Processes all the animations
                    if iii["Type"]=="Destroyed":
                        iii["Current Frame"]+=1
                        if iii["Current Frame"]==50:
                            ii["Type"]="Empty"
                            ii["Filled"]=False
                            animations_removed.append(iii)
                        else:
                            is_being_destroyed=True
                            destroyed_animation_frame=iii["Current Frame"]
                for iii in animations_removed:
                    ii["Animations"].remove(iii)
                if iis.type=="Empty":
                    self.surface.blit(t_spar_space,(I*105-self.camera_x,II*105-self.camera_y))
                    #pygame.draw.rect(self.surface,(45,5,5),(I*105-self.camera_x,II*105-self.camera_y,100,100),0,5) #735,735
                else:
                    self.surface.blit(iis.sprite,(I*105-self.camera_x,II*105-self.camera_y))
        for I,i in enumerate(self.locations["BBoard"]["Map"]):
            for II,ii in enumerate(i):
                for iii in ii["Flags"]:
                    if iii["Type"]=="Card Hovering Over":
                        self.surface.blit(iii["Card Placed"].other_shape,((I-2)*105-self.camera_x,(II-2)*105-self.camera_y))
                ii["Flags"]=[]
        for iterated_card_pile in self.card_piles: #Draws the top card of every card pile
            selected_card_pile=self.locations[iterated_card_pile]
            cards_in_pile=len(selected_card_pile["Cards"])
            if cards_in_pile>0:
                selected_card_pile["Cards"][-1].draw()
                center(selected_card_pile["Cards"][-1].sprite,self.surface,selected_card_pile["Position"][0]-self.camera_x,selected_card_pile["Position"][1]-self.camera_y)                
        if "Hand" in self.locations:
            self.locations["Hand"]["Position"]=[self.camera_x+960,self.camera_y+540+500]
            self.cards_in_hand=len(self.locations["Hand"]["Cards"])
            if self.cards_in_hand>0:
                curvature_settings=self.locations["Hand"]["Curvature Settings"]
                card_distance_from_mouse={}
                for I,iterated_card in enumerate(self.locations["Hand"]["Cards"]):
                    if not iterated_card in [self.locations["Hand"]["Selected Card"],self.locations["Hand"]["Card Rendered On Top"]]:
                        central_offset=-(self.cards_in_hand-1)/2+I #Used to calculate rotation
                        iterated_card.draw()
                        destination_x=self.locations["Hand"]["Position"][0]-((self.cards_in_hand-1)/2-I)*170 #Determines card position in hand
                        destination_y=self.locations["Hand"]["Position"][1]+abs(central_offset)**curvature_settings["Beta"]*curvature_settings["Gamma"] #This is where the schizophrenia starts. I'll forget how this works once i look away, so i must not look away.
                        rotation=curvature_settings["Alpha"]*((self.cards_in_hand-1)/2-I)/((self.locations["Hand"]["Max Cards"]-1)/2)
                        if not iterated_card.vector_space_element.set_up:
                            iterated_card.vector_space_element.setup(destination_x,destination_y)
                        iterated_card.vector_space_element.move_with_easing_motion_to(destination_x,destination_y,20,rotation)
                        center(pygame.transform.rotate(iterated_card.sprite,iterated_card.vector_space_element.rotation),
                            self.surface,iterated_card.vector_space_element.x-self.camera_x,
                            iterated_card.vector_space_element.y-self.camera_y)
                        #center(render_text((round(iterated_card.vector_space_element.x),round(iterated_card.vector_space_element.y)),30,(255,0,0)),self.surface,iterated_card.vector_space_element.x-self.camera_x,iterated_card.vector_space_element.y-self.camera_y)
                        #The line above is used in debug to determine card positions
                    elif iterated_card==self.locations["Hand"]["Card Rendered On Top"]:
                        saved_I=I
                    
                    dist_from_mouse=dist((iterated_card.vector_space_element.x,iterated_card.vector_space_element.y),self.mouse_pos)
                    while dist_from_mouse in card_distance_from_mouse: #Ensures all the elements are of unique distance to the mouse position
                        dist_from_mouse+=0.000001
                    card_distance_from_mouse[dist_from_mouse]=iterated_card #Sets up detection of which card is selected
                    #if dist_from_mouse<192: #If is within a circle of the mouse cursor
                    #    self.drag_screen_allowed=False #You can't drag the screen
                if self.locations["Hand"]["Card Rendered On Top"]!=None: #Brings the topmost rendered card to the very end of the loop, ensuring it is rendered last
                    I=saved_I
                    iterated_card=self.locations["Hand"]["Card Rendered On Top"]
                    central_offset=-(self.cards_in_hand-1)/2+I
                    iterated_card.draw()
                    destination_x=self.locations["Hand"]["Position"][0]-((self.cards_in_hand-1)/2-I)*170 #Determines card position in hand
                    destination_y=self.locations["Hand"]["Position"][1]+abs(central_offset)**curvature_settings["Beta"]*curvature_settings["Gamma"] #This is where the schizophrenia starts. I'll forget how this works once i look away, so i must not look away.
                    rotation=curvature_settings["Alpha"]*((self.cards_in_hand-1)/2-I)/((self.locations["Hand"]["Max Cards"]-1)/2)
                    
                    if not iterated_card.vector_space_element.set_up:
                        iterated_card.vector_space_element.setup(destination_x,destination_y)
                    if iterated_card!=self.locations["Hand"]["Selected Card"]:
                        iterated_card.vector_space_element.move_with_easing_motion_to(destination_x,destination_y,20,rotation)
                        iterated_card.sprite.set_alpha(255)
                        center(pygame.transform.rotate(iterated_card.sprite,iterated_card.vector_space_element.rotation),
                            self.surface,iterated_card.vector_space_element.x-self.camera_x,
                            iterated_card.vector_space_element.y-self.camera_y)
                    else:
                        iterated_card.sprite.set_alpha(100)
                        center(pygame.transform.rotate(iterated_card.sprite,iterated_card.vector_space_element.rotation),
                            self.surface,iterated_card.vector_space_element.x-self.camera_x,
                            iterated_card.vector_space_element.y-self.camera_y)
                        center(pygame.transform.rotate(iterated_card.parent.shape,iterated_card.vector_space_element.rotation),
                            self.surface,iterated_card.vector_space_element.x-self.camera_x,
                            iterated_card.vector_space_element.y-self.camera_y)
                    iterated_card.sprite.set_alpha(255)
                    #center(render_text((round(iterated_card.vector_space_element.x),round(iterated_card.vector_space_element.y)),30,(255,0,0)),self.surface,iterated_card.vector_space_element.x-self.camera_x,iterated_card.vector_space_element.y-self.camera_y)
                    #The line above is used in debug to determine card positions
                    
                    if self.mouse_down[0]:
                        self.locations["Hand"]["Selected Card"]=iterated_card
                        self.locations["Hand"]["Selected Card Original Position"]=(iterated_card.vector_space_element.x,iterated_card.vector_space_element.y)
                if len(self.open_GUIs)==0: #If there are any other GUIs, cards cannot be interacted with
                    if self.locations["Hand"]["Selected Card"]!=None:
                        self.selected_card=self.locations["Hand"]["Selected Card"]
                        self.selected_card.vector_space_element.move_with_easing_motion_to(self.mouse_pos[0],self.mouse_pos[1],4,0)
                        if "BBoard" in self.locations:
                            for I,iterated_row in enumerate(self.locations["BBoard"]["Map"]):
                                for II,iterated_space in enumerate(iterated_row):
                                    distance_from_that_center=dist((I*105+50,II*105+50),
                                                    (self.selected_card.vector_space_element.x,self.selected_card.vector_space_element.y))
                                    if abs(I*105+50-self.selected_card.vector_space_element.x)<52 and abs(II*105+50-self.selected_card.vector_space_element.y)<52:
                                        if (I+self.selected_card.parent.x_size+self.selected_card.parent.x_min<9 and 
                                            II+self.selected_card.parent.y_size+self.selected_card.parent.y_min<9 and 
                                            II+self.selected_card.parent.y_min>-1 and
                                            I+self.selected_card.parent.x_min>-1):
                                            
                                            #print(iterated_space)
                                            t1=True
                                            for iii in self.selected_card.parent.squares:
                                                targeted_space=self.locations["BBoard"]["Map"][I+iii[0]][II+iii[1]]
                                                if not self.selected_card.parent.squares[iii].check_compatibility(targeted_space["Square"]):
                                                    t1=False
                                                    break
                                            if t1:
                                                iterated_space["Flags"].append({
                                                    "Type":"Card Hovering Over",
                                                    "Card Placed":self.selected_card.parent
                                                })
                                                if not self.mouse_down[0]:
                                                    for iii in self.selected_card.parent.squares:
                                                        targeted_space=self.locations["BBoard"]["Map"][I+iii[0]][II+iii[1]]
                                                        targeted_space["Square"]=self.selected_card.parent.squares[iii]
                                                        #targeted_space["Type"]=self.selected_card.parent.squares[iii].type
                                                        #targeted_space["Color"]=self.selected_card.parent.squares[iii].color
                                                        #targeted_space["Filled"]=self.selected_card.parent.squares[iii].filled
                                                        self.score+=1
                                                        self.score+=self.selected_card.parent.mutations
                                                    
                                                    self.locations["Graveyard"]["Cards"].append(self.selected_card)
                                                    #self.selected_card.flip("Front")
                                                    self.locations["Hand"]["Cards"].remove(self.selected_card)
                                                    self.check_bboard_events()
                            if not self.mouse_down[0]:
                                self.locations["Hand"]["Selected Card"]=None
                                self.locations["Hand"]["Card Rendered On Top"]=None
                            else:
                                self.drag_screen_allowed=False
                        else:
                            if not self.mouse_down[0]:
                                self.locations["Hand"]["Selected Card"]=None
                                self.locations["Hand"]["Card Rendered On Top"]=None
                                for iterated_card_space in self.locations["Board"]:
                                    distance_from_that_center=dist((iterated_card_space["X Offset"],iterated_card_space["Y Offset"]),
                                                            (self.selected_card.vector_space_element.x,self.selected_card.vector_space_element.y))
                                    if distance_from_that_center<45:
                                        if iterated_card_space["Type Needed"]==self.selected_card.parent.type:
                                            self.locations["Hand"]["Cards"].remove(self.selected_card)
                                            iterated_card_space["Space"].card=self.selected_card
                                
                                                #if iterated_card_space["Type Needed"]==self.selected_card.parent.type:
                                                #    self.locations["Hand"]["Cards"].remove(self.selected_card)
                                                #    iterated_card_space["Space"].card=self.selected_card
                            else:
                                self.drag_screen_allowed=False
                    else:
                        closest_card_to_mouse_distance=sorted(list(card_distance_from_mouse.keys()))[0]
                        if closest_card_to_mouse_distance<192 or self.locations["Hand"]["Selected Card"]!=None:
                            #self.surface.blit(render_text(closest_card_to_mouse_distance,30,(255,0,0)),(200,0))
                            self.locations["Hand"]["Card Rendered On Top"]=card_distance_from_mouse[closest_card_to_mouse_distance]
                            self.drag_screen_allowed=False
                        else:
                            self.locations["Hand"]["Card Rendered On Top"]=None
        for iterated_card_space in self.locations["Board"]: #Made just now just to remember how stuff works, and to handle attacking.
            if not "Interacting With Card On Field" in self.open_GUIs: #Can't open more than 1 GUI at the same time.
                if "Interactable" in iterated_card_space["Tags"]:  #Checks if the card in this zone can attack
                    if abs(iterated_card_space["X Offset"]-self.mouse_pos[0])<105 and abs(iterated_card_space["Y Offset"]-self.mouse_pos[1])<160: #Detects if the mouse is currently on the current card
                        if iterated_card_space["Space"].card!=None: #Checks if a card exists in that space
                            if self.click[0]:
                                self.open_GUIs["Interacting With Card On Field"]={
                                    "Selected Card":iterated_card_space["Space"].card
                                }
        if "Interacting With Card On Field" in self.open_GUIs:
            interacted_card=self.open_GUIs["Interacting With Card On Field"]["Selected Card"]
            if interacted_card.parent.type=="Creature":
                possible_actions=["Close"]
                #A Nice little block checking all the cases for actions that a creature can do. 
                if interacted_card.parent.attack>0:             possible_actions.append("Attack")
                for I,i in enumerate(possible_actions):
                    action_center_x=960-((len(possible_actions)-1)/2-I)*200
                    pygame.draw.rect(self.surface,(15,15,15),(action_center_x-80,820,160,60),0,10)
                    center(render_text(i,20,(255,255,255)),self.surface,action_center_x,850)
                    if not (abs(self.r_mouse_pos[0]-action_center_x)<80 and abs(self.r_mouse_pos[1]-835)<30): #If The mouse hovers over this button
                        pygame.draw.rect(self.surface,(125,125,125),(action_center_x-80,820,160,60),5,10)
                    else:
                        pygame.draw.rect(self.surface,(175,175,125),(action_center_x-80,820,160,60),5,10) #It Gets a different color
                        if self.click[0]:
                            if i=="Close":
                                del self.open_GUIs["Interacting With Card On Field"]
            #This should be deleted later, as it would be a rather little used feature. 
            elif interacted_card.parent.type=="Chess Piece":
                move_to_squares=[]
                clicktaken=False
                for i in interacted_card.parent.ruleset["Move"]:
                    if i["Type"]=="Single Square":
                        move_to_squares.append(i["Offset"])
                        #pygame.draw.circle(self.surface,(255,255,126),(interacted_card.vector_space_element.x+220*i["Offset"][0]-self.camera_x,interacted_card.vector_space_element.y-220*i["Offset"][1]-self.camera_y-55),15,8)
                    pass
                for i in move_to_squares:
                    for ii in self.locations["Board"]:
                        if ii["Tags"]["Position"]["X"]+i[0]==interacted_card.space["Tags"]["Position"]["X"] and ii["Tags"]["Position"]["Y"]-i[1]==interacted_card.space["Tags"]["Position"]["Y"]:
                            pygame.draw.circle(self.surface,(255,255,126),(interacted_card.space["X Offset"]-self.camera_x,interacted_card.space["Y Offset"]-self.camera_y),15)
                if self.click[0] and not clicktaken:
                    del self.open_GUIs["Interacting With Card On Field"]
            #Chess Piece Ends Here. 
    def update(self): #Updates the board so that 
        self.mouse_rel=pygame.mouse.get_rel()
        self.mouse_down=pygame.mouse.get_pressed()
        self.mouse_pos=pygame.mouse.get_pos()
        self.r_mouse_pos=[self.mouse_pos[i]*self.mouse_pos_multiplier[i] for i in range(2)] #adjusts to the change in resolution
        self.mouse_pos=[self.r_mouse_pos[0]+self.camera_x,self.r_mouse_pos[1]+self.camera_y] #adds the position of camera to the mouse, allowing simple access. 
        if self.mouse_down[0] and self.drag_screen_allowed:
            self.camera_x-=self.mouse_rel[0]
            self.camera_y-=self.mouse_rel[1]
        self.ctimer=[(self.ctimer[i]+1)*self.mouse_down[i] for i in range(3)]
        self.click=[self.ctimer[i]==1 for i in range(3)]
    def add_card_to_game(self,plain_card,plain_card_type="Creature"): #Adds a new card to the game, returns the created card
        new_card=Card() 
        if plain_card_type=="Creature":
            new_object_manager=Creature(plain_card)
            new_object_manager.card=new_card
            new_object_manager.draw() #Draws the new card at the start, so it is visible at all
            new_card.parent=new_object_manager #Also attributes the parent to whatever is locked inside the card
            return new_object_manager.card
        if plain_card_type=="Piece":
            new_object_manager=Piece(plain_card)
            new_object_manager.card=new_card
            new_object_manager.draw() #Draws the new card at the start, so it is visible at all
            new_card.parent=new_object_manager #Also attributes the parent to whatever is locked inside the card
            return new_object_manager.card

    def draw_a_card(self,from_pile="Deck"): #Takes a card from a deck, adds it to the hand, the animation engine itself figures out how to animate that
        if len(self.locations[from_pile]["Cards"])>0:
            drawn_card=self.locations[from_pile]["Cards"][0]
            self.locations[from_pile]["Cards"].pop(0)
            if len(self.locations["Hand"]["Cards"])<self.locations["Hand"]["Max Cards"]:
                self.locations["Hand"]["Cards"].append(drawn_card)
                drawn_card.vector_space_element=Vector_Element()
                drawn_card.vector_space_element.setup(self.locations[from_pile]["Position"][0],self.locations[from_pile]["Position"][1])
                drawn_card.iflip("Back")
                drawn_card.clear_animations()
                drawn_card.flip(40,"Front")
                drawn_card.draw()
            else:
                return "Full Hand"
        else:
            return "Empty Pile"
    def import_deck(self,json_deck_list=[],to_card_pile="Deck"): #Imports deck from a decklist
        # Ideal decklist should be a list consisting of cards in the following format
        # {"Name":"CARD NAME","Type":"CARD TYPE"}
        # This doesn't shuffle the deck, so it has to be done manually
        if not to_card_pile in self.locations:
            self.setup_card_pile(to_card_pile)
        for iterated_card_packed in json_deck_list:
            new_card=self.add_card_to_game(iterated_card_packed["Name"],iterated_card_packed["Type"])
            new_card.iflip("Back")
            self.locations[to_card_pile]["Cards"].append(new_card)
    def shuffle_card_pile(self,card_pile="Deck"):
        shuffle(self.locations[card_pile]["Cards"])
    def check_for_target(self,locations=[]):
        possible_cards=[]
        #First finds all the cards, then removes all the ones that don't count. 
        for i in self.locations:
            if not i in ["Board"]: #Custom Card Location
                if len(locations)>0:
                    if i in locations:
                        #print(i,locations)
                        for card in self.locations[i]["Cards"]:
                            possible_cards.append(card)
                    else:
                        continue
                else:
                    for card in i["Cards"]:
                        possible_cards.append(card)
            else:
                if len(locations)>0:
                    if "Board" in locations:
                        for space in self.locations[i]:
                            if space["Space"].card!=None:
                                possible_cards.append(space["Space"].card)

        #print(possible_cards)
        return possible_cards
    def check_bboard_events(self):
        if self.combo_timer==0:
            self.combo_score=0
        else:
            self.combo_timer-=1
        for i in range(8): #checks all the columns,and if any are filled, they are cleared
            is_all_filled=True
            for ii in range(8):
                t_square=self.locations["BBoard"]["Map"][i][ii]
                if t_square["Square"].filled==False:
                    is_all_filled=False
                    break
            if is_all_filled:
                for ii in range(8):
                    t_square=self.locations["BBoard"]["Map"][i][ii]
                    #t_square["Filled"]=False
                    #t_square["Type"]="Empty"
                    t_square["Square"]=cube("Empty",(0,0,0))
                self.combo_timer=3
                self.combo_score+=1
                self.score+=5*self.combo_score+5
        for ii in range(8): #checks all the rows,and if any are filled, they are cleared
            is_all_filled=True
            for i in range(8):
                t_square=self.locations["BBoard"]["Map"][i][ii]
                if t_square["Square"].filled==False:
                    is_all_filled=False
                    break
            if is_all_filled:
                for i in range(8):
                    t_square=self.locations["BBoard"]["Map"][i][ii]
                    t_square["Square"]=cube("Empty",(0,0,0))
                self.combo_score+=1
                self.score+=5*self.combo_score+5
                self.combo_timer=3
        self.total_moves=0
        self.possible_moves=0
        self.game_over=self.score>0
        for iterated_card in self.locations["Deck"]["Cards"]+self.locations["Hand"]["Cards"]+self.locations["Graveyard"]["Cards"]:
            iterated_card.parent.possible_moves=0
        for x in range(8):
            for y in range(8): #Checks all of the cards in the deck, and checks if they can be placed
                for iterated_card in self.locations["Deck"]["Cards"]+self.locations["Hand"]["Cards"]+self.locations["Graveyard"]["Cards"]:
                    can_be_placed=True
                    for iterated_square in iterated_card.parent.squares:
                        if can_be_placed:
                            if 0<=iterated_square[0]+y<=7 and 0<=iterated_square[1]+x<=7: #Fits on the board
                                if not iterated_card.parent.squares[iterated_square].check_compatibility(self.locations["BBoard"]["Map"][iterated_square[0]+y][iterated_square[1]+x]["Square"]):
                                    can_be_placed=False
                    if can_be_placed:
                        iterated_card.parent.possible_moves+=1
                        self.possible_moves+=1
                    self.total_moves+=1
        
        
        if len(self.locations["Hand"]["Cards"])==0:
            for i in range(3):
                self.draw_a_card()
                if len(self.locations["Deck"]["Cards"])==0:
                    for ii in self.locations["Graveyard"]["Cards"]:
                        self.locations["Deck"]["Cards"].append(ii) #Should Mutate the cards here
                        ii.iflip("Back")
                        ii.parent.mutate()
                    self.locations["Graveyard"]["Cards"]=[]
        for i in self.locations["Hand"]["Cards"]:
            if i.parent.possible_moves>0:
                #print(i.parent.possible_moves)
                self.game_over=False
        #print()
