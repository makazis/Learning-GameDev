from random import *
from math import *
import pygame
import os
import json
pygame.init()
def center(sprite,surface,x,y): #Centers a sprite on specific coordinates
    surface.blit(sprite,(x-sprite.get_width()/2,y-sprite.get_height()/2))

fonts={}
texts={}
def render_text(text="TEXT NOT PROVIDED",size=20,color=(255,255,255),font="comicsansms",bold=False,italic=False): #allows you to render text fast
    font_key=str(font)+str(size)
    text_key=str(font_key)+str(text)+str(color)
    if not font_key in fonts:
        #fonts[font_key]=pygame.font.SysFont(font,int(size)) #Tries to load the file from the system
        try:
            #print(font,size)
            fonts[font_key]=pygame.font.SysFont(font,int(size),bold=bold,italic=italic) #Tries to load the file from the system
        except: #If that doesn't work
            try:
                fonts[font_key]=pygame.font.Font("Resources/Misc/Fonts/"+font+".ttf",int(size)) #Tries to load the font from a specified path, Don't do italic or bold unless very neccessary, bc pygame might do some strange stuff
                #fonts[font_key].bold=bold
                #fonts[font_key].italic=italic joe bidden
            except:
                print(font,"Resources/Misc/Fonts/"+font+".ttf")
                fonts[font_key]=pygame.font.Font("Resources/Misc/Fonts/Roboto-Regular.ttf",int(size)) #Loads the Robotic font provided in resources
                #fonts[font_key].bold=bold
                #fonts[font_key].italic=italicResources\Misc\Fonts\Kreon-Regular.ttf
    if not text_key in texts:
        texts[text_key]=fonts[font_key].render(str(text),1,color)
    return texts[text_key]
class Vector_Element:
    def __init__(self,dimensions=2): #Might extend this later into higher dimensions, but, for now, there is no reason to
        self.dimensions=dimensions
        self.set_up=False
    def setup(self,x,y,rotation=0):
        self.x=x
        self.y=y
        self.rotation=rotation
        self.vectors=[]
        self.set_up=True
    def move_with_easing_motion_to(self,destination_x,destination_y, easing_rate=20,destination_rotation=0): #Higher easing rate means slower easing
        self.x=(self.x*(easing_rate-1)+destination_x)/easing_rate
        self.y=(self.y*(easing_rate-1)+destination_y)/easing_rate
        self.rotation=(self.rotation*(easing_rate-1)+destination_rotation)/easing_rate
card_transparency_overlay=pygame.Surface((210,320))
card_transparency_overlay.set_colorkey((255,255,255))
card_transparency_color=(234,23,4)
card_transparency_overlay.fill((card_transparency_color))
pygame.draw.rect(card_transparency_overlay,(255,255,255),(0,0,210,320),0,15)
def romanify(number):
    output=""
    if number>=100:         number-=100;output+="C"
    elif number>=90:        number-=90; output+="XC"
    if number>=50:          number-=50; output+="L"
    elif number>=40:        number-=40; output+="XL"
    for i in range(3):
        if number>=10:      number-=10; output+="X"
    if number>=9:           number-=9;  output+="IX"
    if number>=5:           number-=5;  output+="V"
    elif number>=4:         number-=4;  output+="IV"
    for i in range(3):
        if number>=1:       number-=1;  output+="I"
    return output
crystal_sprite_base=pygame.image.load("Resources/Sprites/Crystal Base.png")
crystal_sprite=[crystal_sprite_base.copy() for i in range(4)]
for i in range(4):
    crystal_sprite[i].fill([(155,255,255),(0,125,255),(0,155,0),(195,65,0)][i],special_flags=pygame.BLEND_MULT)
s_crystal_sprite=[pygame.transform.scale(crystal_sprite[i],(50,100)) for i in range(4)]
mini_crystal_sprite=[pygame.transform.scale(crystal_sprite[i],(30,60)) for i in range(4)]