expansions=[]
from Library.Expansions.quantum.m import *
expansions.append(Quantum_Expansion)