from Library.Expansions.Scientific.Quantum import *
from Library.Expansions.Scientific.Thermodynamics import *

from Library.Expansions.Basic.count_change import *
from Library.Expansions.Basic.tough_blocks import *
from card import *
from Piece import *
expansions=[]
def get_expansions(packs=[]):
    expansions.append(Basic_Expansion())
    expansions.append(Tough_Expansion())
    
    if "Scientific" in packs:
        expansions.append(Quantum_Expansion())
        expansions.append(Thermal_Expansion())
        
    for i in expansions:
        i.draw()
    