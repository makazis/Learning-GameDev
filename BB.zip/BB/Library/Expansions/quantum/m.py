from Library.Expansions.Main import Expansion

class Quantum_Expansion(Expansion):
    def __init__(self):
        pass