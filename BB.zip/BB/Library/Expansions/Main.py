from random import *
from Piece import *
from card import *
bcto=pygame.transform.scale(card_transparency_overlay,(525,800))#big card transparency Overlay
class Expansion:
    def __init__(self):
        self.card=Card((525,800))
        self.front_sprite=pygame.Surface((525,800))
        self.front_sprite.fill((12,97,70))
        self.display_name="NAME NOT PROVIDED"
        self.display_description=["DESCRIPTION NOT PROVIDED"]
        self.mutations=[]
        self.flags=[]
        self.items=[]
    def draw(self):
        self.front_sprite.fill((5,67,50))
        pygame.draw.rect(self.front_sprite,(69,210,165),(50,5,425,45),3,10)
        center(render_text(self.display_name,(30),(69,210,165),"Kreon-Regular"),self.front_sprite,262,27)
        for i in enumerate(self.display_description):
            center(render_text(i[1],(25),(69,210,165),"Kreon-Regular"),self.front_sprite,262,107+i[0]*30)
        self.card.sides["Front"].blit(self.front_sprite,(0,0))
        self.card.sides["Front"].blit(bcto,(0,0))
    def change_random_cube_to(self,piece,new_cube):
        options=set()
        for i in piece.squares:
            if piece.squares[i].type=="Block":
                options.add(i)
        if len(options)>0:
            chosen_square=choice(list(options))
            piece.squares[chosen_square]=new_cube#
