from random import *
from card import *

class Expansion:
    def __init__(self):
        self.card=Card((525,800))
        self.card.fill((0,0,0))