from Library.Expansions.Main import *
from random import *
class Kinematics_Expansion(Expansion):
    def __init__(self):
        super().__init__()
        self.display_name="Redstone"
        self.display_description=["Puts Redstone on some of the pieces","And adds TNT and Redstone Blocks.","(Trust me, i'm an engineer)"]
        self.mutations=[
            {
                "ID":"Add Redstone",
                "Function":self.a1,
                "Weight":5
            }
        ]
    def a1(self,piece):
        options=set()
        for i in piece.squares:
            if piece.squares[i].filled and piece.addon==None:
                options.add(i)
        if len(options)>0:
            chosen_square=choice(list(options))
            piece.squares[chosen_square].addon="Redstone"
        #self.change_random_cube_to(piece,cube("Kinematic Up",piece.color))