from Library.Expansions.Main import *
from random import *
class Kinematics_Expansion(Expansion):
    def __init__(self):
        super().__init__()
        self.display_name="Moving Pieces"
        self.display_description=["Gives some pieces the ability to move"]
        self.mutations=[
            {
                "ID":"Turn Kinematic Up",
                "Function":self.turn_up,
                "Weight":3
            },
            {
                "ID":"Turn Kinematic Left",
                "Function":self.turn_left,
                "Weight":3
            },{
                "ID":"Turn Kinematic Right",
                "Function":self.turn_right,
                "Weight":3
            },{
                "ID":"Turn Kinematic Down",
                "Function":self.turn_down,
                "Weight":3
            },
        ]
    def turn_up(self,piece):
        self.change_random_cube_to(piece,cube("Kinematic Up",piece.color))
    def turn_down(self,piece):
        self.change_random_cube_to(piece,cube("Kinematic Down",piece.color))
    def turn_left(self,piece):
        self.change_random_cube_to(piece,cube("Kinematic Left",piece.color))
    def turn_right(self,piece):
        self.change_random_cube_to(piece,cube("Kinematic Right",piece.color))
    
