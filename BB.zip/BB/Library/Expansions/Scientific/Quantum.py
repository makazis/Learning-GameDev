from Library.Expansions.Main import *
from random import *
class Quantum_Expansion(Expansion):
    def __init__(self):
        super().__init__()
        print(self.card)
        self.display_name="Negative Pieces"
        self.display_description=["Adds a mutation that turns blocks negative"]
        self.mutations=[
            {
                "ID":"Turn Negative",
                "Function":self.turn_negative,
                "Weight":1
            },{
                "ID":"Turn Half Negative",
                "Function":self.turn_half_negative,
                "Weight":2
            },{
                "ID":"Turn Half Positive",
                "Function":self.turn_half_positive,
                "Weight":2
            }
            ]
    def turn_negative(self,piece):
        self.change_random_cube_to(piece,cube("Negative",piece.color))
    def turn_half_negative(self,piece):
        self.change_random_cube_to(piece,cube("Half Negative",piece.color))
    def turn_half_positive(self,piece):
        self.change_random_cube_to(piece,cube("Half Positive",piece.color))
    