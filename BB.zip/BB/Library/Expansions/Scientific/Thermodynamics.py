from Library.Expansions.Main import *
from random import *
class Thermal_Expansion(Expansion):
    def __init__(self):
        super().__init__()
        print(self.card)
        self.display_name="Thermodynamics"
        self.display_description=["Adds thermodynamics to the game"]
        self.mutations=[
            {
                "ID":"Turn Cold",
                "Function":self.turn_cold,
                "Weight":3
            },{
                "ID":"Turn Hot",
                "Function":self.turn_hot,
                "Weight":3}
            ]
    def turn_cold(self,piece):
        options=set()
        for i in piece.squares:
            if piece.squares[i].type in ["Block","Cold"]:
                options.add(i)
        if len(options)>0:
            chosen_square=choice(list(options))
            if piece.squares[chosen_square].type=="Block":
                piece.squares[chosen_square]=cube("Cold",piece.color)
            elif piece.squares[chosen_square].type=="Cold":
                piece.squares[chosen_square].coldness+=1
    def turn_hot(self,place):
        pass

    