from card import *
from Piece import *
from spells import *
def example_upgrade_function(board):
    board.tech["Crystal Spawns"]+=1
starting_shop_items=[
        {
                "Type":"Piece",
                "Layout":[
                    {
                        "Position":[0,0],
                        "Type":"Block"
                    }
                ],
                "Color":[23,205,23],
                "Cost":{
                    "Earth":randint(randint(1,2),2)
                }
            } for i in range(3)
]+[
    {
        "Type":"Upgrade",
        "ID":"More Crystals",
        "Cost":{
            "Earth":4,
            "Water":4,
            "Air":4,
            "Fire":4,
            
        },
        "Function":example_upgrade_function
        },
    {
        "Type":"Spell",
        "Name":"Pot Of Greed",
        "Sprite Path":"Resources/Sprites/Cards/PotOfGreed.png",
        "Cost":{
                    "Air":randint(randint(1,2),2),
                    "Fire":randint(1,2)
                },
        "Effects":{
            "On Play":[
                {
                    "Type":"Draw Cards",
                    "Cards Drawn":2
                }
            ]
        }
    }
]

class Item:
    def __init__(self,data):
        self.data=data
        self.type=self.data["Type"]
        if self.data["Type"]=="Piece":
            new_card=Card()
            new_object_manager=Piece({"Layout":[]},self.data["Color"])
            for i in self.data["Layout"]:
                new_object_manager.squares[tuple(i["Position"])]=cube(i["Type"],self.data["Color"])
            new_object_manager.card=new_card
            new_object_manager.possible_moves=[None,None]
            new_object_manager.draw() #Draws the new card at the start, so it is visible at all
            new_card.parent=new_object_manager #Also attributes the parent to whatever is locked inside the card
            self.card=new_card
            new_object_manager.update()
        if self.data["Type"]=="Upgrade":
            self.card=Card()
            self.card.sides["Front"].fill((0,25,55))
            self.function=self.data["Function"]
        if self.data["Type"]=="Spell":
            self.name=data["Name"]
            new_card=Card()
            self.card_sprite=pygame.transform.scale(pygame.image.load(data["Sprite Path"]),(210,320))
            new_object_manager=Spell(self.data)
            new_object_manager.card=new_card
            new_object_manager.draw() #Draws the new card at the start, so it is visible at all
            new_card.parent=new_object_manager #Also attributes the parent to whatever is locked inside the card
            self.card=new_card
            self.card.sides["Front"].blit(self.card_sprite,(0,0))
            self.card.sides["Front"].blit(card_transparency_overlay,(0,0))
            self.effects=data["Effects"]
        self.cost=[]
        #for i in range(4):
            #element=["Air","Water","Earth","Fire"][i]
            #if element in self.data["Cost"]:
        self.sprite=pygame.Surface((300,320))
        self.sprite.fill(card_transparency_color)
        self.sprite.set_colorkey(card_transparency_color)
    def draw(self): #Used so that you can flip cards in shop
        self.sprite.fill(card_transparency_color)
        self.card.draw()
        self.sprite.blit(self.card.sprite,(90,0))
        y_stack=0
        for i in range(4):
            element=["Air","Water","Earth","Fire"][i]
            if element in self.data["Cost"]:
                center(mini_crystal_sprite[i],self.sprite,60,64+y_stack*64)
                center(render_text(str(self.data["Cost"][element])),self.sprite,20,64+y_stack*64)
                y_stack+=1
starting_shop_items=[Item(i) for i in starting_shop_items]
