import pygame
from useful_things import *
from math import *
from random import *
import os
import json
import colorsys
Piece_data={}
for root,dirs,files in os.walk(r"Library/Pieces"): #Looks at every single folder within Library/Creatures
    for file in files: #Looks at every single file
        if file.endswith(".json"): #If the file ends with .json
            with open(os.path.join(root,file)) as f: #opens the file in the reading mode
                Piece_data[file[:-5]]=json.loads(f.read()) #sets the files contents as a json object at a key that is the name of the file 
default_cover=pygame.image.load(r"Resources/Sprites/block_covers/default.png")
class cube:
    def __init__(self,_type,_color):
        self.type=_type
        self.sprite=default_cover.copy()
        self.color=_color
        self.sprite.fill(self.color,special_flags=pygame.BLEND_MULT)
        self.small_sprite=pygame.transform.scale(self.sprite,(40,40))
        self.filled=self.type in ["Block","Tough"]
        if self.type=="Negative":
            self.new_sprite=pygame.Surface((100,100))
            self.new_sprite.fill((255,255,255))
            self.new_sprite.blit(self.sprite,(0,0),special_flags=pygame.BLEND_SUB)
            self.sprite=self.new_sprite
            self.small_sprite=pygame.transform.scale(self.sprite,(40,40))
        if self.type=="Empty":
            self.sprite.set_alpha(0)
            self.small_sprite.set_alpha(0)
    def check_compatibility(self,placed_on_square):
        #print(self.type,placed_on_square.filled)
        if self.type in ["Block","Tough"]:
            if placed_on_square.filled==False:
                return True
            else:
                return False
        if self.type in ["Negative"]:
            if placed_on_square.filled==True:
                return True
            else:
                return False
class Piece:
    def __init__(self,data={}):
        self.data=data
        self.sprite=pygame.Surface((210,320))
        self.color=[i*255 for i in colorsys.hsv_to_rgb(random(),1,1)]
        self.lit_color=[min(125,(255-i)*2) for i in self.color]
        

        
        self.type="Piece"
        self.other_shape=pygame.Surface((525,525))
        
        self.other_shape.set_colorkey(card_transparency_color)
        self.other_shape.set_alpha(100)
        self.shape=pygame.Surface((210,320))
        self.possible_moves=[(3,3)]
        self.total_moves=[(3,3)]
        self.shape.set_colorkey(card_transparency_color)
        self.mutations=0
        self.squares={} 
        for i in self.data["Layout"]:
            self.squares[tuple(i)]=cube("Block",self.color)
        self.update()
    def update(self):
        x_min=0
        x_max=0
        y_min=0
        y_max=0
        for i in self.squares:
            x_min=min(x_min,i[0])
            y_min=min(y_min,i[1])
            x_max=max(x_max,i[0])
            y_max=max(y_max,i[1])
        self.x_size=(x_max-x_min+1)
        self.y_size=(y_max-y_min+1)
        self.x_min=x_min
        self.y_min=y_min
    def draw(self):
        self.d_color=[]
        self.d_lit_color=[]
        if len(self.possible_moves)>1:
            self.d_color=self.color
            self.d_lit_color=self.lit_color
        elif len(self.possible_moves)==1:
            self.d_color=[55,55,55]
            self.d_lit_color=[255,125,0]
        else:
            self.d_color=[55,55,55]
            self.d_lit_color=[125,125,125]
        #cq=len(self.possible_moves)/len(self.total_moves)
        #for i in range(3):
        #    self.d_color.append(self.color[i]*cq+(1-cq)*[255,125,0][i])
        #    self.d_lit_color.append(self.lit_color[i]*cq)
        self.sprite.fill(self.d_color)
        self.shape.fill(card_transparency_color)
        self.other_shape.fill(card_transparency_color)
        for i in range(100):
            pygame.draw.polygon(self.sprite,self.d_lit_color,[(0,-210+i*30),(210,0+i*30),(210,15+i*30),(0,-215+i*30)])
        for i in self.squares:
            self.sprite.blit(self.squares[i].small_sprite,(85+i[0]*40,140+i[1]*40))
            self.shape.blit(self.squares[i].small_sprite,(85+i[0]*40,140+i[1]*40))
            self.other_shape.blit(self.squares[i].sprite,(210+i[0]*105,210+i[1]*105))

        self.card.sides["Front"].blit(self.sprite,(0,0))
        self.card.sides["Front"].blit(card_transparency_overlay,(0,0)) #Ran at the end, in case the overlay is missing
    def mutate(self):
        times=int(log(random(),0.2)) #0.2 should be the default value
        for i in range(times):
            selected_mutation=choices([i for i in range(len(mutation_weights))],mutation_weights)[0]
            self.mutations+=1
            if selected_mutation==0: #Places 1 more square
                options=set()
                for ii in range(5): #X
                    ii-=2
                    for iii in range(5): #Y
                        iii-=2
                        if not (ii,iii) in self.squares: #Found an empty square to place new sqaure into
                            for vector in [(0,1),(1,0),(-1,0),(0,-1)]:
                                if -2<=vector[0]+ii<=2 and -2<=vector[1]+iii<=2: #If destination fits inside the square
                                    if (vector[0]+ii,vector[1]+iii) in self.squares:
                                        options.add((ii,iii))
                g=choice(tuple(options))
                self.squares[g]=cube("Block",self.color)
            if selected_mutation==1: #remove a square from the shape at random
                if len(self.squares)>2:
                    del self.squares[choice(tuple(self.squares.keys()))]
            if selected_mutation==2: #Turn square Negative
                #print(self.squares)
                self.squares[choice(tuple(self.squares.keys()))]=cube("Negative",self.color)
            if selected_mutation==3: #Add 1 Durability
                selected_square=choice([ii for ii in self.placement_data if ii["Type"] in ["Block","Tough"]])
                if "Toughness" in selected_square:
                    selected_square["Toughness"]+=1
                else:
                    selected_square["Toughness"]=1
                    selected_square["Type"]="Tough"
        self.update()
        self.draw()
# 5 of each card should be a fun little game
mutation_weights=[
    1,1,1/5
] #remember to normalize this array after
starting_deck=[
    {"Name":i,"Type":"Piece"} for i in Piece_data["blocks"]["A"]
]
for i in Piece_data["blocks"]["A"]:
    for ii in range(ceil(i["Count"]/3)):
        starting_deck.append({
            "Name":i,"Type":"Piece"
        })
shuffle(starting_deck)