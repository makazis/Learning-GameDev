import pygame
from math import *
from random import *
from card import *
from board import * 
pygame.init()
win=pygame.display.set_mode((0,0)) #Sets the screen to fullscreen mode
run=True

board=Board(win.get_size())

board.locations["BBoard"]={
    "Map":[
        [{"Square":cube("Empty",(0,0,0)),"Animations":[],"Flags":[]} for i in range(8)] for i in range(8)
    ]
}
board.setup_hand()
board.locations["Hand"]["Position"][1]-=400
board.setup_card_pile("Deck",(1000,420))
board.setup_card_pile("Graveyard",(1220,420))
board.import_deck(starting_deck,"Graveyard")
board.check_bboard_events()
for i in board.locations["Deck"]["Cards"]:
    i.draw()
#    pygame.image.save(i.sprite,"test_data/"+chr(randint(64,100))+chr(randint(64,100))+chr(randint(64,100))+chr(randint(64,100))+".png")
#    print(i.sprite)
for i in range(1):
    board.draw_a_card()
    board.draw()
while run and not board.game_over:
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            run=False
    win.fill((55,55,55)) #Deletes the screen, fills all with black
    board.draw()
    board.update()
    center(render_text(f"Score: {board.score},combo:{board.combo_score}",(30),(255,255,155),"times new roman"),board.surface,420-board.camera_x,-100-board.camera_y)
    center(render_text(f"{round(board.possible_moves/board.total_moves,8)}",(30),(255,255,155),"times new roman"),board.surface,420-board.camera_x,-60-board.camera_y)
    keys=pygame.key.get_pressed()
    if keys[27]: run=False  
    win.blit(pygame.transform.scale(board.surface,win.get_size()),(0,0))
    win.blit(render_text(f"{board.camera_x},{board.camera_y}"),(5,5))
    pygame.display.update() #Updates the screen
pygame.quit()
print(f"You Lost. Score:{board.score}")