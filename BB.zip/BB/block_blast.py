import pygame
from math import *
from random import *
from card import *
from board import * 
pygame.init()
win=pygame.display.set_mode((0,0)) #Sets the screen to fullscreen mode
run=True

board=Board(win.get_size())

board.locations["BBoard"]={
    "Map":[
        [{"Square":cube(["Empty","Block"][randint(1,2)==0],(255,255,255)),"Animations":[],"Flags":[]} for i in range(8)] for i in range(8)
    ]
}
board.setup_hand()
board.setup_card_pile("Deck",(1000,420))
board.setup_card_pile("Graveyard",(1220,420))
board.import_deck(starting_deck,"Graveyard")
board.check_bboard_events()
for i in board.locations["Deck"]["Cards"]:
    i.draw()
for i in range(1): 
    board.draw_a_card()
    board.draw()
clock=pygame.time.Clock()
debug=False
if debug:
    board.score+=100
    for i in board.currency:
        board.currency[i]+=10
while run and not board.game_over:
    clock.tick()
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            run=False
    win.fill((55,55,55)) #Deletes the screen, fills all with black
    board.update()
    board.draw()    
    if board.score>100:
        for i in range(4):
            center(s_crystal_sprite[i],board.surface,263-board.camera_x+i*100,-170-board.camera_y)
            center(render_text(str(board.currency[["Air","Water","Earth","Fire"][i]]),(30),(255,255,155)),board.surface,300-board.camera_x+i*100,-170-board.camera_y)
    if board.combo_timer>0 and board.combo_score>1:
        size=sin(board.frame/30)*0.4+1.2
        rotation=sin(board.frame/20)*20
        center(pygame.transform.rotate(render_text(f"Score: {int(board.display_score)}",int(30*size),(255,255,155),"times new roman"),rotation),board.surface,420-board.camera_x,-100-board.camera_y)
    else:
        center(render_text(f"Score: {int(board.display_score)}",int(30),(255,255,155),"times new roman"),board.surface,420-board.camera_x,-100-board.camera_y)
    
    center(render_text(f"FPS:{round(clock.get_fps(),2)}",(30),(255,255,155),"times new roman"),board.surface,420-board.camera_x,-60-board.camera_y)
    keys=pygame.key.get_pressed()
    if keys[27]: run=False  
    win.blit(pygame.transform.scale(board.surface,win.get_size()),(0,0))
    win.blit(render_text(f"{board.camera_x},{board.camera_y} {round(board.mouse_pos[0],1)} {round(board.mouse_pos[1],1)}"),(5,5))
    pygame.display.update() #Updates the screen
pygame.quit()
print(f"You Lost. Score:{board.score}")