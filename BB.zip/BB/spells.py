class Spell:
    def __init__(self,data):
        self.data=data
        self.type="Spell"
    def draw(self):
        pass